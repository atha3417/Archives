<?php 
session_start();
include_once '__CONFIG__/config.php';
include_once '__TEMPLATES__/header.php';

if (!isset($_SESSION['login'])) {
	header("Location: auth/login.php");
	exit;
}

if (isset($_POST['tambah'])) {
	$error = false;
	$namaFile = $_POST['namaFile'];
	if (is_file($namaFile)) {
		if (file_exists($namaFile)) {
			$error = 3;
		} else {
			if ($result = mysqli_query($conn, "INSERT INTO file VALUES ('', '$namaFile')")) {
				if (mysqli_affected_rows($result) > 0) {
					if (touch($namaFile)) {
						$succes = 2;
					}
				}
			}
		}
	}
}
?>

<div class="container text-center">
	<div class="row">
		<div class="col-lg-6 offset-3">
			<form action="" method="post">
				<h1 class="mb-3 mt-3">Tambah File</h1>
				<?php if (isset($error) && $error == 3): ?>
					<div class="alert alert-danger text-center">Nama file sudah ada!</div>
				<?php endif ?>
				<div class="form-group">
					<input type="text" name="namaFile" class="form-control" id="nama-file" placeholder="Nama file dengan ekstensi..." autocomplete="off">
				</div>
				<div class="form-group float-left">
					<button type="submit" name="tambah" class="btn btn-primary"><i class="fas fa-fw fa-file-upload"></i> Tambah</button>
				</div>
			</form>
		</div>
	</div>
</div>

<?php include_once '__TEMPLATES__/footer.php'; ?>