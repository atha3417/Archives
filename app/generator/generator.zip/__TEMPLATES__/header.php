<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>__TEMPLATES__/font-awesome-4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>__TEMPLATES__/css/util.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>__TEMPLATES__/css/main.css">
  <script src="https://kit.fontawesome.com/4942ae4d1b.js" crossorigin="anonymous"></script>
  <script src="<?= base_url(); ?>__TEMPLATES__/js/jquery-3.2.1.min.js"></script>

  <title>Generator</title>
</head>
<body>