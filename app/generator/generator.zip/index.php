<?php 
session_start();
include_once '__CONFIG__/config.php';
include_once '__TEMPLATES__/header.php';

if (!isset($_SESSION['login'])) {
	header("Location: auth/login.php");
	exit;
}
?>

<div class="text-center">
	<div class="card">
		<div class="card-body">
			<div class="row">
				<div class="col-lg">
					<h1 class="mb-3 mt-3">Data File</h1>
					<a href="add.php" class="btn btn-primary mb-4 mt-2 float-left"><i class="fas fa-fw fa-file-upload"></i> Tambah File / Folder</a>
					<a href="auth/logout.php" class="btn btn-danger mb-4 mt-2 float-right" onclick="return confirm('Apakah Anda Yakin Ingin Keluar?')"><i class="fas fa-fw fa-sign-out-alt"></i> Keluar</a>
					<table class="table table-hover table-bordered">
						<thead>
							<tr>
								<th>No. </th>
								<th>Nama</th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<?php include_once '__TEMPLATES__/footer.php'; ?>