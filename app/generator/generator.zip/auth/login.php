<?php 
session_start();
include_once '../__CONFIG__/config.php';
include_once '../__TEMPLATES__/header.php';

if (isset($_POST['masuk'])) {
	$username = $_POST['username'];
	$password = $_POST['password'];
	$query = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'") or die (mysqli_error($conn));
	if (mysqli_num_rows($query) > 0) {
		$_SESSION['error'] = false;
		$row = mysqli_fetch_array($query);
		if (sha1($password) == $row['password']) {
			$_SESSION['login'] = true;
		} else {
			$error = 2;
		}
	} else {
		$error = 3;
	}
}

if (isset($_SESSION['login'])) {
	header("Location: http://localhost/generator/");
	exit;
}
?>

<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-100">
				<form class="login100-form validate-form" action="" method="post">
					<span class="login100-form-title p-b-33">Halaman Masuk</span>
					<?php if (isset($error) && $error === 2) { ?>
						<div class="alert alert-danger text-center">Password Salah!</div>
					<?php } else if (isset($error) && $error === 3) { ?>
						<div class="alert alert-danger text-center">Username Tidak ditemukan!</div>
					<?php } ?>
					<div class="wrap-input100 validate-input" data-validate = "Username wajib diisi!">
						<input class="input100" type="text" name="username" placeholder="Username" autocomplete="off">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="wrap-input100 rs1 validate-input" data-validate="Password wajib diisi!">
						<input class="input100" type="password" name="password" placeholder="Password" autocomplete="off">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="container-login100-form-btn m-t-20">
						<button class="login100-form-btn" name="masuk">Masuk</button>
					</div>
				</form>
			</div>
		</div>
	</div>

<?php include_once '../__TEMPLATES__/footer.php'; ?>