<?php 
$conn = mysqli_connect('localhost', 'root', '', 'generator');

function base_url()
{
	return "http://muhtasaq.dev/generator/";
}