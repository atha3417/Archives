<?php 

$conn = mysqli_connect('localhost', 'root', '', 'latihan_teka-teki');

function base_url() {
	return "http://muhtasaq.dev/atha-app/latihan/teka-teki-game/";
}
