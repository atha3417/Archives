<?php
include_once 'assets/header.php';
include_once 'config/config.php';
if (isset($_POST['cek'])) {
	if ($_POST['jawaban'] == $result['jawaban'] || $_POST['jawaban'] == $result['jawaban2']) {
		$tipe = "success";
		$text = "Jawaban Anda Benar!";
	} else {
		$tipe = "danger";
		$text = "Jawaban Anda Salah!";
	}
}
?>

<div class="col-lg-6 offset-3 mt-4">
	<h3 class="text-center"><b>Pertanyaan</b></h3>
	<?php if (isset($tipe)): ?>
		<div class="alert alert-<?= $tipe; ?> text-center"><?= $text; ?></div>
	<?php endif ?>
	<h5 class="text-center text-muted" style="text-align: justify !important; line-height: 30px;"><?= $result['pertanyaan']; ?></h5>
	<form action="" method="post">
		<div class="form-group mt-4">
			<label for="jawaban"><b>Jawaban Anda</b></label>
			<input type="hidden" name="id" value="<?= $result['id']; ?>" hidden>
			<input type="text" name="jawaban" id="jawaban" class="form-control" autocomplete="off" autofocus>
		</div>
		<div class="form-group">
			<?php if (isset($tipe) && $tipe == "success"): ?>
				<button type="submit" name="cek" class="btn btn-success" disabled>Kirim</button>
			<?php else: ?>
				<button type="submit" name="cek" class="btn btn-success">Kirim</button>
			<?php endif ?>
			<?php if (isset($tipe) && $tipe == "success"): ?>
				<button name="lanjut" class="btn btn-primary" <?= $tipe == "success" ? null : "disabled"; ?>>Lanjut</button>
			<?php endif ?>
		</div>
	</form>
</div>

<?php include_once 'assets/footer.php'; ?>